# ngrok + Expo 자동화 스크립트
# 사용법: .\dev-ngrok.ps1

Write-Host "🚀 ngrok + Expo 자동화 시작..." -ForegroundColor Green

# 1. 기존 ngrok 프로세스 종료
Write-Host "📱 기존 ngrok 프로세스 종료 중..." -ForegroundColor Yellow
taskkill /IM ngrok.exe /F 2>$null
Start-Sleep 2

# 2. ngrok 실행 (백그라운드)
Write-Host "🌐 ngrok 실행 중..." -ForegroundColor Yellow
Start-Process ngrok -ArgumentList "http 8000" -WindowStyle Hidden

# 3. ngrok 시작 대기
Write-Host "⏳ ngrok 시작 대기 중..." -ForegroundColor Yellow
Start-Sleep 5

# 4. ngrok URL 가져오기
try {
    $response = Invoke-RestMethod "http://127.0.0.1:4040/api/tunnels" -TimeoutSec 10
    $ngrokUrl = $response.tunnels[0].public_url
    
    Write-Host "✅ ngrok URL 획득: $ngrokUrl" -ForegroundColor Green
    
    # 5. PC의 로컬 IP 자동 감지
    $localIP = (Get-NetIPAddress -AddressFamily IPv4 | Where-Object {$_.IPAddress -like "192.168.*"} | Select-Object -First 1).IPAddress
    if (-not $localIP) {
        $localIP = "192.168.1.100" # fallback IP
    }
    
    # 6. 환경변수 설정 (플랫폼별)
    $env:EXPO_PUBLIC_IOS_API_BASE_URL = $ngrokUrl
    $env:EXPO_PUBLIC_ANDROID_API_BASE_URL = "http://${localIP}:8000"
    
    Write-Host "🔧 iOS/Web 환경변수 설정: EXPO_PUBLIC_IOS_API_BASE_URL = $ngrokUrl" -ForegroundColor Green
    Write-Host "🔧 Android 환경변수 설정: EXPO_PUBLIC_ANDROID_API_BASE_URL = http://${localIP}:8000" -ForegroundColor Green
    
    # 7. lib/api.ts 파일 자동 업데이트
    $apiFile = "lib\api.ts"
    if (Test-Path $apiFile) {
        $content = Get-Content $apiFile -Raw
        # iOS/Web ngrok URL 업데이트
        $newContent = $content -replace "https://[a-zA-Z0-9]+\.ngrok-free\.app", $ngrokUrl
        # Android 로컬 IP 업데이트
        $newContent = $newContent -replace "http://192\.168\.\d+\.\d+:8000", "http://${localIP}:8000"
        Set-Content $apiFile $newContent -Encoding UTF8
        Write-Host "📝 lib/api.ts 파일 자동 업데이트 완료" -ForegroundColor Green
    }
    
    # 8. Expo 앱 실행
    Write-Host "📱 Expo 앱 시작 중..." -ForegroundColor Green
    Write-Host "🔗 API Base URL: $ngrokUrl" -ForegroundColor Cyan
    Write-Host "💡 Ctrl+C로 중지할 수 있습니다." -ForegroundColor Yellow
    
    npx expo start --clear
    
} catch {
    Write-Host "❌ ngrok URL 가져오기 실패: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "🔧 수동으로 ngrok을 실행하고 URL을 확인해주세요." -ForegroundColor Yellow
    exit 1
}

