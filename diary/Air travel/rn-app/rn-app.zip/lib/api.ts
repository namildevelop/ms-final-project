﻿// API 설정 파일
import { Platform } from 'react-native';

export const getApiUrl = () => {
  let API_BASE: string;
  
  if (Platform.OS === 'android') {
    // 안드로이드: 로컬 네트워크 IP 사용
    API_BASE = process.env.EXPO_PUBLIC_ANDROID_API_BASE_URL || 'http://192.168.56.1:8000';
    console.log("🔍 Android API BASE =", API_BASE);
  } else {
    // iOS/웹: ngrok URL 사용
    API_BASE = process.env.EXPO_PUBLIC_IOS_API_BASE_URL || 'https://3bbc12dbb15b.ngrok-free.app';
    console.log("🔍 iOS/Web API BASE =", API_BASE);
  }
  
  return API_BASE;
};

export const API_ENDPOINTS = {
  signup: '/auth/signup',
  login: '/auth/login',
  emailRequestVerify: '/email/request-verify',
  emailVerifyCode: '/email/verify/code',
  profileComplete: '/users/profile/complete',
  me: '/users/me',
  checkEmail: '/users/check/email',
  checkUsername: '/users/check/username',
  reverseGeocode: '/kakao/coord2address',  // 백엔드 경로와 일치하도록 수정
  searchAddress: '/kakao/search',
};

// API 호출 헬퍼 함수
export const apiCall = async (endpoint: string, options: RequestInit = {}) => {
  const baseUrl = getApiUrl();
  const url = `${baseUrl}${endpoint}`;
  
  const response = await fetch(url, {
    headers: {
      'Content-Type': 'application/json',
      ...options.headers,
    },
    ...options,
  });
  
  if (!response.ok) {
    throw new Error(`API Error: ${response.status}`);
  }
  
  return response.json();
};




























